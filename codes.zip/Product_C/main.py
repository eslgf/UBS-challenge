import QuantLib as ql
import numpy as np
import pandas as pd

a = 0.132542
sigma = 0.029412
r0 = 0.035428
T = 10
L_low = 0.025
L_high = 0.045
N = 20000000
R = 0.08


calendar = ql.TARGET()
settlement_date = ql.Date().todaysDate()
ql.Settings.instance().evaluationDate = settlement_date
maturity_date = settlement_date + int(T * 365)


day_count = ql.Actual360()
flat_rate = ql.QuoteHandle(ql.SimpleQuote(r0))
term_structure = ql.YieldTermStructureHandle(ql.FlatForward(settlement_date, flat_rate, day_count))


hw_process = ql.HullWhiteProcess(term_structure, a, sigma)


num_paths = 10000
time_steps = 365

def simulate_rate_paths(process, num_paths, time_steps, maturity_date):
    dt = T / time_steps
    paths = np.zeros((num_paths, time_steps + 1))
    for i in range(num_paths):
        path = [r0]
        for j in range(1, time_steps + 1):
            dw = np.random.normal(0, np.sqrt(dt))
            dr = process.drift(j * dt, path[-1]) * dt + process.diffusion(j * dt, path[-1]) * dw
            path.append(path[-1] + dr)
        paths[i, :] = path
    return paths

paths = simulate_rate_paths(hw_process, num_paths, time_steps, maturity_date)
pathpd = pd.DataFrame(paths)
pathpd.to_excel('path.xlsx')


long_term_rates = np.mean(paths, axis=1)


payment_prob = np.mean((long_term_rates >= L_low) & (long_term_rates <= L_high))


discount_factor = term_structure.discount(maturity_date)


price = N * R * payment_prob * discount_factor

print(f"Product Price: {price:.2f}")