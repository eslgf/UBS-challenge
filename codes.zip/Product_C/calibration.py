import numpy as np
import pandas as pd
from scipy.optimize import minimize


data = pd.read_csv('rates.csv')
data['Date'] = pd.to_datetime(data['Date'])
data.set_index('Date', inplace=True)
rates = data['Rate'].values


delta_t = 1 / 252


def negative_log_likelihood(params):
    a, sigma = params
    n = len(rates)
    residuals = rates[1:] - rates[:-1] + a * rates[:-1] * delta_t
    likelihood = -np.sum(-0.5 * np.log(2 * np.pi) - 0.5 * np.log(sigma**2 * delta_t) - (residuals**2) / (2 * sigma**2 * delta_t))
    return -likelihood


initial_guess = [0.1, 0.01]


result = minimize(negative_log_likelihood, initial_guess, bounds=((0, None), (0, None)))


a_opt, sigma_opt = result.x
print(f"Estimated a: {a_opt}")
print(f"Estimated sigma: {sigma_opt}")