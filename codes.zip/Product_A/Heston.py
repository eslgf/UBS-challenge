# -*- coding: utf-8 -*-
# by Lanyu Li
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import configparser
from scipy.integrate import quad
from scipy.optimize import minimize
from datetime import datetime as dt


class hestonParams:
    def __init__(self, future_path, option_path, record_date, record_price, r):
        self.future_path = future_path
        self.option_path = option_path
        # 用于记录数据保存的日期及对应的点位数据，填充option数据
        self.record_date = record_date
        self.record_price = record_price

        self.r = r

    def _read_data(self):
        future = pd.read_excel(self.future_path)
        future.columns
        future.Date = pd.to_datetime(future.Date)
        future = future[['Date', 'Close*']]
        future.columns = ['date', 'price']

        volCurve = pd.read_csv(self.option_path)
        # 过滤一些数据
        # volCurve = volCurve.loc[np.logical_and(volCurve['Type'] == 'Call', volCurve['Volume'] > 10),:]
        volCurve = volCurve.loc[volCurve['Volume'] > 10, :]
        volCurve = volCurve[['Strike', 'Last', 'Volume', 'Last Trade', 'Type', 'Maturity']]
        volCurve['Last Trade'] = pd.to_datetime(volCurve['Last Trade'])
        volCurve['Maturity'] = pd.to_datetime(volCurve['Maturity'])
        volCurve['Type'] = volCurve['Type'].str.lower()
        volCurve['Strike'] = [float(i) for i in volCurve['Strike'].str[:-1].str.replace(',', '')]

        self.future = future
        self.volCurve = volCurve

    def _heston_charfunc(self, phi, S0, v0, kappa, theta, sigma, rho, lambd, tau, r):
        # 常数
        a = kappa * theta
        b = kappa + lambd
        # 常用乘子
        rspi = rho * sigma * phi * 1j

        # 计算d和g
        d = np.sqrt((rho * sigma * phi * 1j - b) ** 2 + (phi * 1j + phi ** 2) * sigma ** 2)
        g = (b - rspi + d) / (b - rspi - d)

        # 计算特征方程phi
        exp1 = np.exp(r * phi * 1j * tau)
        term2 = S0 ** (phi * 1j) * ((1 - g * np.exp(d * tau)) / (1 - g)) ** (-2 * a / sigma ** 2)
        if np.isnan(term2):
            print(1)
        exp2 = np.exp(a * tau * (b - rspi + d) / sigma ** 2 + v0 * (b - rspi + d) * (
                    (1 - np.exp(d * tau)) / (1 - g * np.exp(d * tau))) / sigma ** 2)

        return exp1 * term2 * exp2

    def _integrand(self, phi, S0, v0, kappa, theta, sigma, rho, lambd, tau, r, K):
        # 计算heston解析式中的积分项，给定phi计算值
        args = (S0, v0, kappa, theta, sigma, rho, lambd, tau, r)
        numerator = np.exp(r * tau) * self._heston_charfunc(phi - 1j, *args) - K * self._heston_charfunc(phi, *args)
        denominator = 1j * phi * K ** (1j * phi)
        return numerator / denominator

    def heston_price(self, S0, K, v0, kappa, theta, sigma, rho, lambd, tau, r, type ='call'):
        # 调包计算积分
        # type 指示期权类型
        if np.isscalar(S0) == True:
            args = (S0, v0, kappa, theta, sigma, rho, lambd, tau, r, K)
            real_integral, err = np.real(quad(self._integrand, 0, 100, args=args)) # 积分上界过高会overflow
            if type == 'call':
                value = (S0 - K * np.exp(-r * tau)) / 2 + real_integral / np.pi
            elif type == 'put':
                value = K * np.exp(-r * tau) + (S0 - K * np.exp(-r * tau)) / 2 + real_integral / np.pi - S0
        else:
            value = np.zeros_like(S0)
            for i in range(len(S0)):
                args = (S0[i], v0, kappa, theta, sigma, rho, lambd, tau[i], r, K[i])
                temp, err = np.real(quad(self._integrand, 0, 100, args=args, limit=5000)) # 积分上界过高会overflow
                if type[i] == 'call':
                    value[i] = (S0[i] - K[i] * np.exp(-r * tau[i])) / 2 + temp / np.pi
                elif type[i] == 'put':
                    value[i] = K[i] * np.exp(-r * tau[i]) + (S0[i] - K[i] * np.exp(-r * tau[i])) / 2 + temp / np.pi - \
                               S0[i]
                else:
                    print(f'类型指示错误, i = {i}')
                    value = np.nan

        return value

    def _SqErr(self, x, args):
        # 用于计算平方损失函数
        S0, K, tau, r, P, type = [arg for arg in args]
        v0, kappa, theta, sigma, rho, lambd = [param for param in x]

        err = np.sum((P - self.heston_price(S0, K, v0, kappa, theta, sigma, rho, lambd, tau, r, type)) ** 2 / len(P))

        # 对于偏离猜测值的惩罚项
        # pen = abs(sigma / 0.10 - 1) * err # 对于偏离初始值的惩罚项
        # pen = 0
        pen = -np.minimum(2*kappa*theta - sigma**2, 0) * err # 对于Feller condition的惩罚项，使vol过程尽量为正

        return err + pen

    def _residual(self, x, args):
        # 用于计算残差
        S0, K, tau, r, P, type = [arg for arg in args]
        v0, kappa, theta, sigma, rho, lambd = [param for param in x]

        residual = P - self.heston_price(S0, K, v0, kappa, theta, sigma, rho, lambd, tau, r, type)

        return residual

    def heston_params(self):
        self._read_data()
        # 根据数据集设置期权参数
        future = self.future.copy()
        volCurve = self.volCurve.copy()

        future_price = self.record_price
        volCurve['S'] = future_price
        for date in volCurve['Last Trade'].unique():
            if pd.to_datetime(date) in [pd.to_datetime(d) for d in future['date']]:
                volCurve.loc[volCurve['Last Trade'] == date, 'S'] = float(future.loc[future['date'] == date, 'price'])
            else:
                # 历史数据里没有的都用当天日期填充
                volCurve.loc[volCurve['Last Trade'] == date, 'S'] = future_price

        S0 = volCurve['S'].values
        K = volCurve['Strike'].values
        tau = pd.Series([dtm.days / 365 for dtm in (volCurve['Maturity'] - volCurve['Last Trade'])]).values
        r = 0.025
        P = volCurve['Last'].values
        type = volCurve['Type'].values
        self.option_args = (S0, K, tau, r, P, type)

        # 设置heston模型参数
        params = {"v0": {"x0": 0.1, "bounds": [0.01, 0.5]},
                  "kappa": {"x0": 3, "bounds": [0.30, 5.0]},
                  "theta": {"x0": 0.05, "bounds": [0.01, 0.5]},
                  "sigma": {"x0": 0.3, "bounds": [0.05, 1]},
                      "rho": {"x0": -0.1, "bounds": [-1, 1]},
                  "lambd": {"x0": 0.03, "bounds": [-1, 1]},
                  }

        x0 = [param["x0"] for key, param in params.items()]
        bounds = [param["bounds"] for key, param in params.items()]
        #优化求解
        import warnings
        warnings.filterwarnings("ignore")

        loss_func = lambda x: self._SqErr(x, self.option_args)
        estimation = minimize(loss_func, x0, tol=1e-8, method='SLSQP', options={'maxiter': 1e4}, bounds=bounds)

        warnings.resetwarnings()

        v0, kappa, theta, sigma, rho, lambd = estimation.x
        self.params = (v0, kappa, theta, sigma, rho, lambd)
        return v0, kappa, theta, sigma, rho, lambd

    def compare_estimation(self):
        # 比较模型价格与实际价格
        S0, K, tau, r, P, type = [i for i in self.option_args]
        v0, kappa, theta, sigma, rho, lambd = [i for i in self.params]
        volCurve = self.volCurve.copy()
        # 验证结果
        result = volCurve[['Strike', 'Volume', 'Type', 'Last']].copy()
        result['heston'] = self.heston_price(S0, K, v0, kappa, theta, sigma, rho, lambd, tau, r, type)
        result['diff'] = result['heston'] - result['Last']
        result['diff%'] = (result['heston'] - result['Last']) / result['Last']
        return result


class hestonBinary:
    # 计算支付金额为1的binary
    def __init__(self, S0, K, v0, kappa, theta, sigma, rho, lambd, tau, r, type):
        self.S0, self.K, self.tau, self.r = S0, K, tau, r
        self.v0, self.kappa, self.theta, self.sigma, self.rho, self.lambd = v0, kappa, theta, sigma, rho, lambd
        self.type = type

    def _heston_charfunc(self, phi, S0, v0, kappa, theta, sigma, rho, lambd, tau, r):
        # 常数
        a = kappa * theta
        b = kappa + lambd
        # 常用乘子
        rspi = rho * sigma * phi * 1j

        # 计算d和g
        d = np.sqrt((rho * sigma * phi * 1j - b) ** 2 + (phi * 1j + phi ** 2) * sigma ** 2)
        g = (b - rspi + d) / (b - rspi - d)

        # 计算特征方程phi
        exp1 = np.exp(r * phi * 1j * tau)
        term2 = S0 ** (phi * 1j) * ((1 - g * np.exp(d * tau)) / (1 - g)) ** (-2 * a / sigma ** 2)
        if np.isnan(term2):
            print(1)
        exp2 = np.exp(a * tau * (b - rspi + d) / sigma ** 2 + v0 * (b - rspi + d) * (
                    (1 - np.exp(d * tau)) / (1 - g * np.exp(d * tau))) / sigma ** 2)

        return exp1 * term2 * exp2

    def _integrand(self, phi, S0, v0, kappa, theta, sigma, rho, lambd, tau, r, K):
        # 计算heston解析式中的积分项，给定phi计算值
        args = (S0, v0, kappa, theta, sigma, rho, lambd, tau, r)
        numerator = self._heston_charfunc(phi, *args) * np.exp(-1j * phi * np.log(K))
        denominator = 1j * phi
        return numerator / denominator

    def heston_price(self):
        S0, K, tau, r = self.S0, self.K, self.tau, self.r
        v0, kappa, theta, sigma, rho, lambd = self.v0, self.kappa, self.theta, self.sigma, self.rho, self.lambd
        type = self.type
        # 调包计算积分
        # type 指示期权类型
        if np.isscalar(S0) == True:
            args = (S0, v0, kappa, theta, sigma, rho, lambd, tau, r, K)
            real_integral, err = np.real(quad(self._integrand, 0, 100, args=args)) # 积分上界过高会overflow
            if type == 'call':
                value = 1 / 2 + real_integral / np.pi
            elif type == 'put':
                value = 1 * np.exp(-r * tau) - (1 / 2 + real_integral / np.pi)
        else:
            value = np.zeros_like(S0)
            for i in range(len(S0)):
                args = (S0[i], v0, kappa, theta, sigma, rho, lambd, tau[i], r, K[i])
                temp, err = np.real(quad(self._integrand, 0, 100, args=args, limit=5000)) # 积分上界过高会overflow
                if type[i] == 'call':
                    value[i] = 1 / 2 + temp / np.pi
                elif type[i] == 'put':
                    value[i] = 1 * np.exp(-r * tau[i]) - (1 / 2 + temp / np.pi - S0[i])
                else:
                    print(f'类型指示错误, i = {i}')
                    value = np.nan

        return value


class hestonVanilla:
    def __init__(self, S0, K, v0, kappa, theta, sigma, rho, lambd, tau, r, type):
        self.S0, self.K, self.tau, self.r = S0, K, tau, r
        self.v0, self.kappa, self.theta, self.sigma, self.rho, self.lambd = v0, kappa, theta, sigma, rho, lambd
        self.type = type

    def _heston_charfunc(self, phi, S0, v0, kappa, theta, sigma, rho, lambd, tau, r):
        # 常数
        a = kappa * theta
        b = kappa + lambd
        # 常用乘子
        rspi = rho * sigma * phi * 1j

        # 计算d和g
        d = np.sqrt((rho * sigma * phi * 1j - b) ** 2 + (phi * 1j + phi ** 2) * sigma ** 2)
        g = (b - rspi + d) / (b - rspi - d)

        # 计算特征方程phi
        exp1 = np.exp(r * phi * 1j * tau)
        term2 = S0 ** (phi * 1j) * ((1 - g * np.exp(d * tau)) / (1 - g)) ** (-2 * a / sigma ** 2)
        if np.isnan(term2):
            print(1)
        exp2 = np.exp(a * tau * (b - rspi + d) / sigma ** 2 + v0 * (b - rspi + d) * (
                    (1 - np.exp(d * tau)) / (1 - g * np.exp(d * tau))) / sigma ** 2)

        return exp1 * term2 * exp2

    def _integrand(self, phi, S0, v0, kappa, theta, sigma, rho, lambd, tau, r, K):
        # 计算heston解析式中的积分项，给定phi计算值
        args = (S0, v0, kappa, theta, sigma, rho, lambd, tau, r)
        numerator = self._heston_charfunc(phi, *args) * np.exp(-1j * phi * np.log(K))
        denominator = 1j * phi
        return numerator / denominator

    def heston_price(self):
        S0, K, tau, r = self.S0, self.K, self.tau, self.r
        v0, kappa, theta, sigma, rho, lambd = self.v0, self.kappa, self.theta, self.sigma, self.rho, self.lambd
        type = self.type
        # 调包计算积分
        # type 指示期权类型
        if np.isscalar(S0) == True:
            args = (S0, v0, kappa, theta, sigma, rho, lambd, tau, r, K)
            real_integral, err = np.real(quad(self._integrand, 0, 100, args=args)) # 积分上界过高会overflow
            if type == 'call':
                value = (S0 - K * np.exp(-r * tau)) / 2 + real_integral / np.pi
            elif type == 'put':
                value = K * np.exp(-r * tau) + (S0 - K * np.exp(-r * tau)) / 2 + real_integral / np.pi - S0
        else:
            value = np.zeros_like(S0)
            for i in range(len(S0)):
                args = (S0[i], v0, kappa, theta, sigma, rho, lambd, tau[i], r, K[i])
                temp, err = np.real(quad(self._integrand, 0, 100, args=args, limit=5000)) # 积分上界过高会overflow
                if type[i] == 'call':
                    value[i] = (S0[i] - K[i] * np.exp(-r * tau[i])) / 2 + temp / np.pi
                elif type[i] == 'put':
                    value[i] = K[i] * np.exp(-r * tau[i]) + (S0[i] - K[i] * np.exp(-r * tau[i])) / 2 + temp / np.pi - \
                               S0[i]
                else:
                    print(f'类型指示错误, i = {i}')
                    value = np.nan

        return value


if __name__ == '__main__':
    # 算参数
    # future_path, option_path, record_date, record_price, r
    gold_index_path = './data/gold index.xlsx'
    gold_option_path = './data/gcq24-options-monthly-options-exp-06_25_24-near-the-money-stacked-intraday-05-24-2024.csv'
    gold_date = '2024-05-24'
    gold_price = 2362.90  # 2024/05/24取值于yahoo finance
    gold_index = hestonParams(gold_index_path, gold_option_path, gold_date, gold_price, 0.025)
    gold_index.heston_params()
    compare = gold_index.compare_estimation()
    plt.hist(compare['diff%'])

    # 二元期权定价
    ini_file_path = './params_gold_copper 10e-8.ini'
    def read_params(ini_file_path):
        if not os.path.exists(ini_file_path):
            # gold params
            print('calculating gold params...')
            gold_index = hestonParams(gold_index_path, gold_option_path, gold_date, gold_price, r)
            v0, kappa, theta, sigma, rho, lambd = gold_index.heston_params()
            gold_params = {'v0':v0,
                           'kappa':kappa,
                           'theta':theta,
                           'sigma':sigma,
                           'rho':rho,
                           'lambda':lambd}
            gold_compare = gold_index.compare_estimation()
            gold_compare.to_excel(f'gold_compare{ini_file_path[-9:-4]}.xlsx')

            # copper params
            print('calculating copper params...')
            copper_index = hestonParams(copper_index_path, copper_option_path, copper_date, copper_price, r)
            v0, kappa, theta, sigma, rho, lambd = copper_index.heston_params()
            copper_params = {'v0':v0,
                           'kappa':kappa,
                           'theta':theta,
                           'sigma':sigma,
                           'rho':rho,
                           'lambda':lambd}
            copper_compare = copper_index.compare_estimation()
            copper_compare.to_excel(f'copper_compare{ini_file_path[-9:-4]}.xlsx')

            print('complete!')

            # 保存参数
            config = configparser.ConfigParser()
            config['Gold'] = gold_params
            config['Copper'] = copper_params

            with open(ini_file_path, 'w') as configfile:
                config.write(configfile)
        else:
            # 读取现有ini文件
            print('read params from .ini')
            config = configparser.ConfigParser()
            config.read(ini_file_path)
            gold_params = {key: float(value) for key, value in config['Gold'].items()}
            copper_params = {key: float(value) for key, value in config['Copper'].items()}

        params_all = pd.DataFrame({'gold': gold_params,
                                   'copper': copper_params})
        return params_all
    params_all = read_params(ini_file_path)
    #copper
    v0, kappa, theta, sigma, rho, lambd = params_all.iloc[:, 0]
    S0, K, tau, r = 100, 100, 2, 0.045
    #S0, v0, kappa, theta, sigma, rho, lambd, tau, r
    binary = hestonBinary(S0, K, v0, kappa, theta, sigma, rho, lambd, tau, r, 'call').heston_price()

    # 尝试静态复制
    '''
    多头：binary(tau_i, coupon/12)
    空头：- binary(T, 5%S, K = 0.95S) - put(T, K = 0.95S) + put(T, K = 0.90S)
    '''

    S = 100
    coupon = 0.08
    positive = 0
    for i in range(18):
        positive += hestonBinary(S0, 1.05*S, v0, kappa, theta, sigma, rho, lambd, 1/12 * i, r, 'call').heston_price() * coupon*S/12
    negative = - hestonBinary(S0, 0.95 * S, v0, kappa, theta, sigma, rho, lambd, 1.5, r, 'put').heston_price() * 0.05*S\
            - hestonVanilla(S0, 0.95 * S, v0, kappa, theta, sigma, rho, lambd, 1.5, r, 'put').heston_price()\
            + hestonVanilla(S0, 0.90 * S, v0, kappa, theta, sigma, rho, lambd, 1.5, r, 'put').heston_price()
    print([positive, negative])

# '''
# 调参：
# r在类内统一，用于定价和路径生成
# minimize的tol参数可调
# tau按照到期日期/365计算，若有需要可以按照美国日历取交易日数量，但是目前的数据来看ttm太少了
# 是否要过滤volumn低的数据?目前过滤了
#
# 问题：
# 数据太少，且流动性差
# 用put call parity计算了put的价格
# '''


