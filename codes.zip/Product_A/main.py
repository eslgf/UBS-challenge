# -*- coding: utf-8 -*-
# by Lanyu Li
import sys
sys.stdout.reconfigure(encoding='utf-8')  # 改变编码方式为UTF-8
# print(sys.stdout.encoding)  # 查看当前的编码方式

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import configparser
from Heston import hestonParams
from scipy.stats import norm

if __name__ == "__main__":
    # 5.16的2Y Daily Treasury Par Yield Curve Rates, from https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?type=daily_treasury_yield_curve&field_tdr_date_value=2024
    r = 0.0478
    # region读取数据，以及读取（或根据期权数据计算）参数
    gold_index_path = './data/gold index.xlsx'
    gold_option_path = './data/gcq24-options-monthly-options-exp-06_25_24-near-the-money-stacked-intraday-05-24-2024.csv'
    gold_date = '2024-05-24'
    gold_price = 2362.90  # 2024/05/24取值于yahoo finance
    copper_index_path = './data/copper index.xlsx'
    copper_option_path = './data/hgn24-options-monthly-options-exp-05_28_24-near-the-money-stacked-intraday-05-13-2024.csv'
    copper_date = '2024-05-14'
    copper_price = 4.7860  # 2024/05/14 取值于yahoo finance

    ini_file_path = './params_gold_copper 10e-8.ini'

    def read_params(ini_file_path):
        if not os.path.exists(ini_file_path):
            # gold params
            print('calculating gold params...')
            gold_index = hestonParams(gold_index_path, gold_option_path, gold_date, gold_price, r)
            v0, kappa, theta, sigma, rho, lambd = gold_index.heston_params()
            gold_params = {'v0':v0,
                           'kappa':kappa,
                           'theta':theta,
                           'sigma':sigma,
                           'rho':rho,
                           'lambda':lambd}
            gold_compare = gold_index.compare_estimation()
            gold_compare.to_excel(f'gold_compare{ini_file_path[-9:-4]}.xlsx')

            # copper params
            print('calculating copper params...')
            copper_index = hestonParams(copper_index_path, copper_option_path, copper_date, copper_price, r)
            v0, kappa, theta, sigma, rho, lambd = copper_index.heston_params()
            copper_params = {'v0':v0,
                           'kappa':kappa,
                           'theta':theta,
                           'sigma':sigma,
                           'rho':rho,
                           'lambda':lambd}
            copper_compare = copper_index.compare_estimation()
            copper_compare.to_excel(f'copper_compare{ini_file_path[-9:-4]}.xlsx')

            print('complete!')

            # 保存参数
            config = configparser.ConfigParser()
            config['Gold'] = gold_params
            config['Copper'] = copper_params

            with open(ini_file_path, 'w') as configfile:
                config.write(configfile)
        else:
            # 读取现有ini文件
            print('read params from .ini')
            config = configparser.ConfigParser()
            config.read(ini_file_path)
            gold_params = {key: float(value) for key, value in config['Gold'].items()}
            copper_params = {key: float(value) for key, value in config['Copper'].items()}

        params_all = pd.DataFrame({'gold': gold_params,
                                   'copper': copper_params})
        return params_all

    # 合并gold和copper价格数据
    gold_index = pd.read_excel(gold_index_path)[['Date', 'Close*']]
    copper_index = pd.read_excel(copper_index_path)[['Date', 'Close*']]
    index_paths = pd.merge(gold_index, copper_index, on='Date')
    index_paths = index_paths.dropna()

    params_all = read_params(ini_file_path)
    #endregion


    #region 生成路径
    # 设置生成路径的参数
    T = 1.5
    simulation = 300000
    N = int(252 * T)
    S0_arr = np.repeat(100., len(index_paths.columns))  # 模拟过程中标的价格使用百分数
    # 根据指数历史数据计算dWt1相关系数矩阵，根据heston参数确定dwt2和dwt1的相关系数；同时假定标的之间的vol of vol不相关
    logreturn = np.log(index_paths.set_index('Date').iloc[::-1,:].shift(-1) / index_paths.set_index('Date').iloc[::-1,:]).dropna()
    price_corr_mat = np.corrcoef(logreturn.T)           # 一年期标的价格log return相关系数

    #生成路径
    def generate_path_heston_QE(price_corr_mat, params_all, S0_arr, T, N, simulation):
        # 生成两个标的的路径（如果需要改为多个标的，则需要在up_all随机数生成部分加一个维度）
        v0_arr = params_all.loc['v0', :].values
        up1 = np.random.uniform(0, 1, [simulation, N])
        up_temp = np.random.uniform(0, 1, [simulation, N])
        price_corr = price_corr_mat[0, 1]
        up2 = up1 * price_corr + up_temp * (1 - price_corr)
        up_all = np.array([up1, up2])

        # 根据dWt生成Vt和St
        price_path_all = []
        vol_path_all = []
        for j in range(len(v0_arr)):
            dt = T / N
            # price_Wt = price_Wt_all[j, :, :].T
            # vol_Wt = vol_Wt_all[j, :, :].T
            v0, kappa, theta, sigma, rho, lambd = params_all.iloc[:, j]

            S = np.full(shape=(N + 1, simulation), fill_value=S0_arr[j])
            v = np.full(shape=(N + 1, simulation), fill_value=v0_arr[j])

            Phic = 1.5
            for i in range(0, N):
                # QE法迭代vol过程
                m = theta + (v[i] - theta) * np.exp(-kappa * dt)
                s2 = v[i] * sigma ** 2 * np.exp(-kappa * dt) / kappa * (
                        1 - np.exp(-kappa * dt)) + theta * sigma ** 2 / 2 / kappa * (1 - np.exp(-kappa * dt)) ** 2
                Phi = s2 / m ** 2
                uv = np.random.uniform(0, 1, simulation)

                temp1_ind = Phi <= Phic
                b2, a, v_temp1 = np.zeros_like(Phi), np.zeros_like(Phi), np.zeros_like(Phi)
                b2[temp1_ind] = 2 / Phi[temp1_ind] - 1 + (2 / Phi[temp1_ind]) ** 0.5 * (2 / Phi[temp1_ind] - 1) ** 0.5
                if np.sum(np.isnan(b2)) > 0:
                    np.argmax(np.isnan(b2))
                    j = np.argmax(np.isnan(b2))
                    pass
                a[temp1_ind] = m[temp1_ind] / (1 + b2[temp1_ind])
                zv = norm.ppf(uv)
                v_temp1[temp1_ind] = a[temp1_ind] * (b2[temp1_ind] ** 0.5 + zv[temp1_ind]) ** 2

                temp2_ind = Phi > Phic
                p, beta, v_temp2 = np.zeros_like(Phi), np.zeros_like(Phi), np.zeros_like(Phi)
                p[temp2_ind] = (Phi[temp2_ind] - 1) / (Phi[temp2_ind] + 1)
                beta[temp2_ind] = (1 - p[temp2_ind]) / m[temp2_ind]
                v_temp2[temp2_ind] = (uv[temp2_ind] <= p[temp2_ind]) * 0 + \
                                     (1 - uv[temp2_ind] <= p[temp2_ind]) * 1 / beta[temp2_ind] * np.log(
                    (1 - p[temp2_ind]) / (1 - uv[temp2_ind]))
                v_temp2[v_temp2 < 0] = 0

                # v[i + 1] = (Phi <= Phic) * v_temp1 + (1 - (Phi <= Phic)) * v_temp2
                v[i + 1, temp1_ind] = v_temp1[temp1_ind]
                v[i + 1, temp2_ind] = v_temp2[temp2_ind]

                # exact representation模拟price过程
                ga1 = 0.5
                ga2 = 1 - ga1  # 中心离散化方法，两边权重相同
                k0 = -rho * kappa * theta / sigma * dt
                k1 = ga1 * dt * (rho * kappa / sigma - 0.5) - rho / sigma
                k2 = ga2 * dt * (rho * kappa / sigma - 0.5) + rho / sigma
                k3 = ga1 * dt * (1 - rho ** 2)
                k4 = ga2 * dt * (1 - rho ** 2)
                # 取根据价格相关性生成的随机数
                up = up_all[j, :, i]
                zp = norm.ppf(up)
                # S在论文基础上增加了drift部分，直接参考了欧拉离散化公式中的drift部分
                S[i + 1] = np.exp(np.log(S[i]) + (r - 0.5 * v[i] ** 2) * dt + k0 + k1 * v[i] + k2 * v[i + 1] + (
                        k3 * v[i] + k4 * v[i + 1]) ** 0.5 * zp)

            price_path_all.append(S.T)
            vol_path_all.append(v.T)
        price_path_all = np.array(price_path_all)
        vol_path_all = np.array(vol_path_all)

        return price_path_all, vol_path_all
    print(f'generating {simulation} paths to gold and copper future prices ...')
    price_path_all, vol_path_all = generate_path_heston_QE(price_corr_mat, params_all, S0_arr, T, N, simulation)

    #endregion

    # 计算期权票息
    def get_fair_coupon(price_aggr):
        S = 100
        Sd = 90
        Su = 103
        coupon = 0.20
        upper = 1.05
        lower = 0.95
        ifki = np.min(price_aggr, axis=1) < Sd
        ifaboveupper_monthly = price_aggr[:, 1::21] > S * upper
        ifabove95_monthly = price_aggr[:, 1::21] > S * 0.95
        ifabove_S_monthly = price_aggr[:, 1::21] > S
        ifabove_S_expr = price_aggr[:, -1] > S
        ifabove95_expr = price_aggr[:, -1] > S * 0.95
        ifabovelower_expr = price_aggr[:, -1] > S * lower
        ifko = np.max(price_aggr[:, 1::21], axis=1) > Su
        ncoupon = np.array(price_aggr[:, 1::21] > S).argmax(axis=1) + 1

        settings = \
            '''
            高保底雪球
            敲出观察日触及敲出：ko, 票息并终止
            未敲入未敲出：1-ki, 1-ko拿满票息
            敲入且未敲出：ki, 1-ko 承担亏损部分，最多10%
            '''
        option_price = np.mean(
            ifko * ncoupon * S * coupon / 12 + \
            (1 - ifki) * (1 - ifko) * coupon * S * T + \
            ifki * (1 - ifko) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0), -0.1 * S)
        )
        fair_coupon = np.sum(0 - ifki * (1 - ifko) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0), -0.1 * S)) / \
                      np.sum((ifko * ncoupon * S / 12 + (1 - ifki) * (1 - ifko) * S * T))
        print(settings, f'票息率 = {fair_coupon}')

        settings = \
            '''
            仅有一个观察日的区间计息
            到期日标的价格高于起初价格S：拿满票息
            到期日标的价格低于期初价格S：承担亏损，最大亏损10%
            '''
        option_price = np.mean(
            ifabove_S_expr * S * coupon * T + \
            (1 - ifabove_S_expr) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0), -0.1 * S)
        )
        fair_coupon = np.sum(0 - (1 - ifabove_S_expr) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0), -0.1 * S)) / \
                      np.sum(ifabove_S_expr * S * T)
        print(settings, f'票息率 = {fair_coupon}')

        settings = \
            '''
            每月观察的区间计息
            观察日标的价格高于起初价格S：拿一份票息
            到期日标的价格低于期初价格S：承担亏损，最大亏损10%
            '''
        option_price = np.mean(
            np.sum(ifabove_S_monthly, axis=1) * S * coupon / 12 * T + \
            (1 - ifabove_S_expr) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0), -0.1 * S)
        )
        fair_coupon = np.sum(0 - (1 - ifabove_S_expr) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0), -0.1 * S)) / \
                      np.sum(np.sum(ifabove_S_monthly, axis=1) * S / 12 * T)
        print(settings, f'票息率 = {fair_coupon}')

        settings = \
            '''
            每月观察的区间计息，下跌参与率50%
            观察日标的价格高于起初价格S：拿一份票息
            到期日标的价格低于期初价格S：承担亏损，最大亏损10%（对应标的亏损20%）
            '''
        option_price = np.mean(
            np.sum(ifabove_S_monthly, axis=1) * S * coupon / 12 * T + \
            (1 - ifabove_S_expr) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0) * 0.5, -0.1 * S)
        )
        fair_coupon = np.sum(0 - (1 - ifabove_S_expr) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0) * 0.5, -0.1 * S)) / \
                      np.sum(np.sum(ifabove_S_monthly, axis=1) * S / 12 * T)
        print(settings, f'票息率 = {fair_coupon}')

        settings = \
            '''
            每月观察的区间计息，计息和亏损点位调至95%
            观察日标的价格高于0.95S：拿一份票息
            到期日标的价格低于0.95S：承担亏损，最大亏损10%
            '''
        option_price = np.mean(
            np.sum(ifabove95_monthly, axis=1) * S * coupon / 12 * T + \
            (1 - ifabove95_expr) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0), -0.1 * S)
        )
        fair_coupon = np.sum(0 - (1 - ifabove95_expr) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0), -0.1 * S)) / \
                      np.sum(np.sum(ifabove_S_monthly, axis=1) * S / 12 * T)
        print(settings, f'票息率 = {fair_coupon}')

        settings = \
            f'''
            每月观察的区间计息，亏损点位调至95%
            观察日标的价格高于{upper}S：拿一份票息
            到期日标的价格低于{lower}S：承担亏损，最大亏损10%
            '''
        option_price = np.mean(
            np.sum(ifaboveupper_monthly, axis=1) * S * coupon / 12 * T + \
            (1 - ifabovelower_expr) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0), -0.1 * S)
        )
        fair_coupon = np.sum(0 - (1 - ifabovelower_expr) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0), -0.1 * S)) / \
                      np.sum(np.sum(ifaboveupper_monthly, axis=1) * S / 12 * T)

    # 尝试best-of，worst-of, mean三种情况
    # price_aggr_best = price_path_all.max(axis = 0)
    # get_fair_coupon(price_aggr_best)
    price_aggr_worst = price_path_all.min(axis = 0)
    # get_fair_coupon(price_aggr_worst)
    # price_aggr_avg = price_path_all.mean(axis = 0)
    # get_fair_coupon(price_aggr_avg)
    # 通过尝试确定了产品结构为每月观察的区间计息

    # 计算选定结构的票息
    def calculate_price(price_aggr):
        S = 100
        coupon = 0.20
        upper = 1.05
        lower = 0.95
        ifaboveupper_monthly = price_aggr[:, 1::21] > S * upper
        ifabovelower_expr = price_aggr[:, -1] > S * lower

        settings = \
            f'''
            每月观察的区间计息
            观察日标的价格高于{upper}S：拿一份票息
            到期日标的价格低于{lower}S：承担亏损，最大亏损10%
            '''
        option_price = np.mean(
            np.sum(ifaboveupper_monthly, axis=1) * S * coupon / 12 * T * np.exp(-r * T)+ \
            (1 - ifabovelower_expr) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0), -0.1 * S) * np.exp(-r * T)
        )
        fair_coupon = np.sum(0 - (1 - ifabovelower_expr) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0), -0.1 * S)) / \
                      np.sum(np.sum(ifaboveupper_monthly, axis=1) * S / 12 * T)
        option_price = (
            np.sum(ifaboveupper_monthly, axis=1) * S * fair_coupon / 12 * T + \
            (1 - ifabovelower_expr) * np.maximum(np.minimum(price_aggr[:, -1] - S, 0), -0.1 * S)
        )
        sd = option_price.std()/(len(price_aggr))**0.5

        return [fair_coupon, option_price.mean(), sd]
    settings =  f'''
每月观察的区间计息
观察日标的价格高于1.05S：拿一份票息
到期日标的价格低于0.95S：承担亏损，最大亏损10%
                '''
    price_results = calculate_price(price_aggr_worst)
    print(settings,'\n',
          f'计算得公允票息应为{price_results[0]}, 估计标准误为{price_results[2]}','\n',
          f'每月支付票息为{price_results[0]/12}')
    #向下取两位小数百分数作为月付票息
    print(f'取两位小数后的月付票息为{int(price_results[0]/12*10000)/100}%, '
          f'对应年化票息为{int(price_results[0]/12*10000)/100*12}%')

graphs = False

# '''
# 问题：
# 没有直接利用历史数据中的波动率之间的相关性，而是通过价格相关性以及heston的rho间接构建波动率随机数之间的相关关系
#
# 结论：
# worst of的月频区间计息可以实现13%的年化收益(一年期限)，均值能实现5.3%，best of仅有1.7%
# '''

#画图等
if graphs == True:
    # 查看生成的vol路径和price路径
    samp = 10
    j = 0
    for i in range(samp):
        plt.plot(np.linspace(1,N,vol_path_all[0].shape[1]), vol_path_all[j,i,:] ** 0.5)
    plt.xlabel('Days')
    plt.ylabel('Volatility')
    plt.title('Volatility paths of Gold Future')
    plt.show()
    for i in range(samp):
        plt.plot(np.linspace(1,N,price_path_all[0].shape[1]), price_path_all[j,i,:])
    plt.xlabel('Days')
    plt.ylabel('Price %')
    plt.title('Price paths of Gold Future')
    plt.show()

    j = 1
    for i in range(samp):
        plt.plot(np.linspace(1,N,vol_path_all[0].shape[1]), vol_path_all[j,i,:] ** 0.5)
    plt.xlabel('Days')
    plt.ylabel('Volatility')
    plt.title('Volatility paths of Copper Future')
    plt.show()
    for i in range(samp):
        plt.plot(np.linspace(1,N,price_path_all[0].shape[1]), price_path_all[j,i,:])
    plt.xlabel('Days')
    plt.ylabel('Price')
    plt.title('Price paths of Copper Future')
    plt.show()

    # 查看生成路径的logreturn corr
    log_return0 = np.log(pd.DataFrame(price_path_all[0,:,:]).shift(-1,axis = 1) / pd.DataFrame(price_path_all[0,:,:]))
    log_return1 = np.log(pd.DataFrame(price_path_all[1,:,:]).shift(-1,axis = 1) / pd.DataFrame(price_path_all[1,:,:]))
    log_return = np.array([log_return0.values, log_return1.values])
    nums = 1000
    corr_arr = np.zeros(nums)
    for i in range(nums):
        corr_arr[i] = np.corrcoef(log_return[0,i,:-1],log_return[1,i,:-1])[0,1]
    plt.hist(corr_arr)
    plt.xlabel('Correlation Coefficients')
    plt.title('Hist of Corr of price paths')

    est = corr_arr.mean()
    se = corr_arr.std()/simulation**0.5
    print(f'corr of gold and copper simulation corr = {est}, se = {se}')

    # 研究一下历史价格的相关性
    logreturn = np.log(index_paths.set_index('Date').iloc[::-1, :].shift(-1) / index_paths.set_index('Date').iloc[::-1, :]).dropna()
    corr_arr = logreturn.iloc[::-1,:].rolling(window = 60).corr()[::2]['Close*_y'].values
    plt.plot(corr_arr)
    plt.xlabel('Days')
    plt.ylabel('Correlation Coefficients')
    plt.title('Correlation Coefficients of Historical Price Data - 60 days rolling')
    # 历史数据的corr
    print('historical corr mat',price_corr_mat)

    # logreturn = np.log(index_paths.set_index('Date').iloc[::-1, :].shift(-1) / index_paths.set_index('Date').iloc[::-1, :]).dropna()
    # vol = (logreturn.rolling(window = 60).std()*(252**0.5)) ** 2
    # plt.plot(vol.values[:,0])
    # plt.plot(vol.values[:,1])
    # df = pd.merge(logreturn.reset_index(), vol.reset_index(), on = 'Date').reset_index(drop = True)
    # df.columns = ['Date', 'gold', 'copper', 'gold_vol', 'copper_vol']
    # df[['Date', 'gold', 'gold_vol']].set_index('Date').rolling(window = 60).corr()[::2]['gold_vol'].values
    # df[['Date', 'copper', 'copper_vol']].set_index('Date').rolling(window = 60).corr()[::2]['copper_vol'].values

    plt.close('all')